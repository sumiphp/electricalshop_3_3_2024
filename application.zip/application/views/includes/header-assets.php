
    <?php $sitedetails = sitedetails(); ?>
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=$sitedetails['favicon']?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/bootstrap.min.css"> 
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?=site_url()?>assets/css/owl.carousel.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/magnific-popup.min.css">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/animate.min.css">
    <!-- Boxicons CSS --> 
    <link rel="stylesheet" href="<?=site_url()?>assets/css/boxicons.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/fonts/flaticon.css">
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/meanmenu.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/responsive.css">
    <!-- Theme Dark CSS -->
    <link rel="stylesheet" href="<?=site_url()?>assets/css/theme-dark.css">