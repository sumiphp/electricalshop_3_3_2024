<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright <?=date('Y')?> <?=sitename()?>. All right reserved.<br>Created with <i class="fa fa-heartbeat"></i> by <?=DEVELOPER_COMPANY?></p>
    </div>
</footer>
<!-- footer area end-->