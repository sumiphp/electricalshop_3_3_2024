<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_dashboard extends Ifix_Model
{
	public function __construct()
    {   
        parent::__construct();
    }
}