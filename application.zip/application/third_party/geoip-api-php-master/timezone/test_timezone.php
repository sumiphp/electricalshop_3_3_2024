<?php
require("../src/timezone.php");
print get_time_zone("CA", "ON");
?>
