var Dashboard = function() {

    varstart = function () {

    }

    return {
        init: function() {
            start();
        },
    };

}(jQuery);
